package test;

import java.util.Scanner;
import static calculadora.Operaciones.*;

public class Calculadora {

    public static void main(String[] args) {
        System.out.println("Proporciona el primer valor: ");
        Scanner scanner = new Scanner(System.in);
        int entero1 = scanner.nextInt();
        System.out.println("Proporciona el segundo valor:");
        int entero2 = scanner.nextInt();
        int resultadoSuma = sumar(entero1, entero2);
        System.out.println("resultadoSuma = " + resultadoSuma);
        int resultadoResta = restar(entero1, entero2);
        System.out.println("resultadoResta = " + resultadoResta);
        int resultMultiplica = multiplicar(entero1, entero2);
        System.out.println("resultadoMultiplicacion = " + resultMultiplica);
        int resultadoDivision = dividir(entero1, entero2);
        System.out.println("resultadoDivision = " + resultadoDivision);
        
    }

}
