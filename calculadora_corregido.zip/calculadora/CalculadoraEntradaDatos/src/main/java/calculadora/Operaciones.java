package calculadora;

public class Operaciones {

    public static int sumar(int entero1, int entero2) {
        return entero1 + entero2;
    }
    
    public static int restar(int entero1, int entero2) {
    return entero1 - entero2;
    }
    
    public static int multiplicar(int entero1, int entero2) {
        return entero1 * entero2;
    }
    
    public static int dividir(int entero1, int entero2) {
        return entero1 / entero2;
    }
}
